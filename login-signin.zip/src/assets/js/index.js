document.getElementById('test').onclick=()=>{
    window.open("./login.html");
}